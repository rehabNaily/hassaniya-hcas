# Data

## Source corpus (not redistributed)

HASSANIYA Dataset, El Arby (2025), Mendeley Data, v1, CC BY 4.0, https://doi.org/10.17632/m2swkr2bhx.1
File used: `projectHA_DATASET - VF.csv` (1,852 rows, 1,851 with a valid label; 1,840 after cleaning).
SHA-256 of the copy used in the paper: `280521b5a1000edb417fd540ac21738a6708884b7814fdd30a192cfe21b8ce2a`

## hcas_ratings.csv (CC BY 4.0)

One row per annotated text (200 rows). The sample was drawn at random from the cleaned corpus, stratified by label,
with seed 42; the main notebook re-draws it and checks that it matches this file.

| Column | Meaning |
|---|---|
| `id` | Text identifier in the source corpus |
| `label` | Original sentiment label of the corpus |
| `CDI_raw`, `CDI_group` | Cultural-Dialectal Index and its group (Low / Medium / High) |
| `affect_A1_round1`, `affect_A2_round1` | Affect ratings (1-5) of annotators 1 and 2, first round |
| `affect_A1_round2`, `affect_A2_round2` | Affect ratings after the calibration round (used in the analyses) |
| `cultural_A1`, `cultural_A2` | Cultural grounding ratings (1-5) |
| `linguistic_A1`, `linguistic_A2` | Linguistic authenticity ratings (1-5) |

Only the affect dimension was re-rated in round 2. H-CAS_human, the summary score used in the paper, is the mean of
the two annotators' cultural and linguistic ratings.

Note: the rating file given to the annotators also displayed the original label and the CDI of each text (see the
Limitations section of the paper).

## hcas_ratings_round2.csv

The exact rating file read by the notebooks (SHA-256 `ef77daf3e604d6f089816f7a2b93ce2ffe4783a90c5e8970689639b46b2cf900`).
It contains the same ratings as `hcas_ratings.csv` under the column names used in the code (`affect_A1`, `affect_A2`
are the round-2 affect ratings) plus derived columns. Do not edit it: the notebooks check its checksum.

## data_splits_ids.csv, corpus_cdi_scores.csv

Copied from the output of the main notebook (`tables/`). Split identifiers allow the exact train / validation / test
partition to be rebuilt from the source corpus.
