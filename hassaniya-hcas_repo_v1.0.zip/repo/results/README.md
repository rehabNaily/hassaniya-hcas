# Results

Copy here, from the Kaggle outputs, the following files (they are produced by the notebooks; nothing is edited by hand):

From the main notebook output `Hassaniya_HCAS_v7_2/`:
* `SYNTHESIS_v7_2.json`, `environment.json`, `requirements_frozen.txt`
* `tables/` (all CSV files) and `figures/` (PNG and PDF)

From the LLM notebook output `Hassaniya_HCAS_v7_2_LLM_open/`:
* `SYNTHESIS_LLM_open.json` and `tables/` (put them in `results/llm/`)
