"""Recompute the inter-annotator agreement reported in the paper (Table 5) from data/hcas_ratings.csv.

Usage:  python scripts/compute_iaa.py
Needs:  pandas, numpy, scipy, scikit-learn (see requirements.txt). Runs in a few seconds on a CPU.
"""
import os
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import cohen_kappa_score

N_BOOT, SEED = 1000, 42
HERE = os.path.dirname(os.path.abspath(__file__))
R = pd.read_csv(os.path.join(HERE, "..", "data", "hcas_ratings.csv"))


def kripp_alpha_ordinal(a, b, cats=(1, 2, 3, 4, 5)):
    """Krippendorff's alpha, ordinal metric, two coders, no missing values."""
    k = len(cats)
    ix = {c: i for i, c in enumerate(cats)}
    o = np.zeros((k, k))
    for x, y in zip(a, b):
        o[ix[int(x)], ix[int(y)]] += 1
        o[ix[int(y)], ix[int(x)]] += 1
    nc = o.sum(1)
    n = nc.sum()
    d = np.zeros((k, k))
    for i in range(k):
        for j in range(k):
            lo, hi = min(i, j), max(i, j)
            d[i, j] = (nc[lo:hi + 1].sum() - (nc[lo] + nc[hi]) / 2) ** 2
    de = (np.outer(nc, nc) * d).sum() / (n * (n - 1))
    return np.nan if de == 0 else 1 - ((o * d).sum() / n) / de


def agreement(a, b):
    a, b = np.asarray(a, int), np.asarray(b, int)
    rng = np.random.default_rng(SEED)
    boot = [cohen_kappa_score(a[i], b[i], weights="quadratic")
            for i in (rng.integers(0, len(a), len(a)) for _ in range(N_BOOT))]
    lo, hi = np.nanpercentile(boot, [2.5, 97.5])
    return {
        "LWK": cohen_kappa_score(a, b, weights="linear"),
        "QWK": cohen_kappa_score(a, b, weights="quadratic"), "QWK_lo": lo, "QWK_hi": hi,
        "alpha_ord": kripp_alpha_ordinal(a, b), "Spearman": spearmanr(a, b)[0],
        "Exact": np.mean(a == b), "Within1": np.mean(np.abs(a - b) <= 1),
        "mean_A1": a.mean(), "mean_A2": b.mean(),
    }


rows = [
    ("Affect, round 1", "affect_A1_round1", "affect_A2_round1"),
    ("Affect, round 2", "affect_A1_round2", "affect_A2_round2"),
    ("Cultural grounding", "cultural_A1", "cultural_A2"),
    ("Linguistic authenticity", "linguistic_A1", "linguistic_A2"),
]
table = pd.DataFrame([{"Dimension": name, **agreement(R[a], R[b])} for name, a, b in rows])
pd.set_option("display.width", 200)
print(f"Agreement between the two annotators (n = {len(R)}), 95% bootstrap CI for QWK ({N_BOOT} resamples)")
print(table.round(3).to_string(index=False))

print("\nStability of affect ratings between rounds (same annotator):")
for ann in ("A1", "A2"):
    q = cohen_kappa_score(R[f"affect_{ann}_round1"], R[f"affect_{ann}_round2"], weights="quadratic")
    print(f"  {ann}: QWK round 1 vs round 2 = {q:.3f}")
